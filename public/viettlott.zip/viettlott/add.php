<?php

header('Access-Control-Allow-Origin: *');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vietlott";
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (isset($_POST["action"]) && $_POST["action"] == "add") {
    $conn->beginTransaction();
    try {
        $stmt_1 = $conn->prepare("INSERT INTO `power_655`(`stages`,`number_1`, `number_2`, `number_3`, `number_4`, `number_5`, `number_6`, `number_7`, `date_run`) 
	VALUES (:stages,:number_1,:number_2,:number_3,:number_4,:number_5,:number_6,:number_7,:date_run)");
        $stmt_1->execute([
            ':stages' => $_POST['stages'],
            ':number_1' => $_POST['number_1'],
            ':number_2' => $_POST['number_2'],
            ':number_3' => $_POST['number_3'],
            ':number_4' => $_POST['number_4'],
            ':number_5' => $_POST['number_5'],
            ':number_6' => $_POST['number_6'],
            ':number_7' => $_POST['number_7'],
            ':date_run' => $_POST['date_run']
        ]);
        $lastInsertId = $conn->lastInsertId();
        $stmt_2 = $conn->prepare("INSERT INTO `power_655_price`(`power_655_id`, `jackpot_1`, `jackpot_2`) VALUES (:power_655_id,:jackpot_1,:jackpot_2)");
        $isOk = $stmt_2->execute([
            ':power_655_id' => $lastInsertId,
            ':jackpot_1' => $_POST['jackpot_1'],
            ':jackpot_2' => $_POST['jackpot_2']
        ]);
        $conn->commit();
        echo json_encode([
            "status" => true,
            "msg" => "Add database success"
        ]);
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode([
            "status" => false,
            "msg" => $e->getMessage()
        ]);
    }
}
