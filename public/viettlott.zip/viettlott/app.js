$(document).ready(() => {
    $("body").append(`<a href="javascript:start_collect()" 
    style="position: fixed;z-index:999999;background-color: #0033ff;padding: 15px 20px;width: 127px;height: 49px;left: 30px;top: 50%;border-radius: 5px;color: #fff;"
    >Start Collect</a>`)
    //start_collect();
});

const start_collect = () => {
    const number_1 = $(".day_so_ket_qua_v2 span:nth-child(1)").text(),
        number_2 = $(".day_so_ket_qua_v2 span:nth-child(2)").text(),
        number_3 = $(".day_so_ket_qua_v2 span:nth-child(3)").text(),
        number_4 = $(".day_so_ket_qua_v2 span:nth-child(4)").text(),
        number_5 = $(".day_so_ket_qua_v2 span:nth-child(5)").text(),
        number_6 = $(".day_so_ket_qua_v2 span:nth-child(6)").text(),
        number_7 = $(".day_so_ket_qua_v2 span:nth-child(8)").text(),
        numer_id = $(".chitietketqua_title h5 b:nth-child(1)").text(),
        date_run = $(".chitietketqua_title h5 b:nth-child(2)").text().split("/").reverse().join("-"),
        jackpot_1 = $("table tbody tr:nth-child(1) td:nth-child(4)").text().replaceAll(".", ""),
        jackpot_2 = $("table tbody tr:nth-child(2) td:nth-child(4)").text().replaceAll(".", "");

    $.ajax({
        url: "http://localhost/viettlott/add.php",
        type: "POST",
        data: {
            action: "add",
            stages: numer_id.replace("#", ""),
            number_1: number_1,
            number_2: number_2,
            number_3: number_3,
            number_4: number_4,
            number_5: number_5,
            number_6: number_6,
            number_7: number_7,
            date_run: date_run,
            jackpot_1: jackpot_1,
            jackpot_2: jackpot_2,
        },
        success: (data) => {
            console.log(data)
            //console.log(JSON.parse(data))
            const result = JSON.parse(data);
            if (result.status) {
                document.querySelector(".btn_chuyendulieu_right").click();
                setTimeout(() => {
                    start_collect();
                }, 2000);
            } else {
                alert(result.msg);
            }
        }
    });
}